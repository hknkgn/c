#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct komsu{
    int plaka;
    struct komsu* next;
}komsu;

typedef struct list{
	int plaka;
	char name[15];
	char bolge[2];
	int komsuSayisi;
	struct list* next;
	struct komsu* komsu;
}list;

void addItem(list ** head, list newItem) // listenin sonuna ekliyor.
{
    list *newNode, *temp;

    newNode = (list*)malloc(sizeof(list));

    if(newNode == NULL)
    {
        printf("Unable to allocate memory.");
    }
    else
    {
        newNode->plaka = newItem.plaka;
        newNode->komsuSayisi = newItem.komsuSayisi;
        strcpy(newNode->name,newItem.name);
        strcpy(newNode->bolge,newItem.bolge);
        newNode->next = NULL; 
        temp = *head;

        if(temp == NULL)
        {	
        	temp = newNode;
        	*head = temp;
        	return;
        }

        // Son düğüme geçiş
        while(temp->next != NULL)
            temp = temp->next;

        temp->next = newNode; // Link address part
    }
}

void printNode(list * node)
{
	printf("{%d,%s,%s,%d}\n", node->plaka,node->name,node->bolge,node->komsuSayisi);
}

void printList(list * mainList)
{
	list * current = mainList;
	while(current != NULL)
	{	
		printNode(current);
		current = current->next;
	}

}

void printByBolge(list * mainList,char bolge[2])
{
	list * head = mainList;
	while(head!=NULL)
	{
		if(strcmp(head->bolge,bolge) == 0)
			printNode(head);
		head = head->next;
	}
}

void findAndPrintByPlaka(list * mainList,int plaka)
{
	list * head = mainList;
	while(head!=NULL)
	{
		if(head->plaka == plaka){
			printNode(head);
			return;
		}
		head = head->next;
	}
}

void printBiggerKomsu(list * mainList,int komsuSayisi)
{
	list * head = mainList;
	while(head!=NULL)
	{
		if(head->komsuSayisi > komsuSayisi){
			printNode(head);
			
		}
		head = head->next;
	}
}

void printSmallerKomsu(list * mainList,int komsuSayisi)
{
	list * head = mainList;
	while(head!=NULL)
	{
		if(head->komsuSayisi < komsuSayisi){
			printNode(head);
		}
		head = head->next;
	}
}

void printEqualKomsu(list * mainList,int komsuSayisi)
{
	list * head = mainList;
	while(head!=NULL)
	{
		if(head->komsuSayisi == komsuSayisi){
			printNode(head);
		}
		head = head->next;
	}
}

void findAndPrintByName(list * mainList,char name [15])
{
	list * head = mainList;
	while(head!=NULL)
	{
		if(strcmp(head->name,name) == 0){
			printNode(head);
		}
		head = head->next;
	}
}

int main(int argc, char const *argv[])
{	

	
	list * mainList = NULL;
	
	FILE * fp;
    char * line = NULL;
    size_t len = 0;
    size_t read;
    char * token;

    fp = fopen("sehirler.txt", "r");

    char ** tokens;
    char * pt;
    while ((read = getline(&line, &len, fp)) != -1) {


            pt = strtok (line,",");
            int i = 0;
            list tmp;
		    while (pt != NULL) 
		    {
		    	if(i<3){
		    		//printf("%s\n", pt);
		    		if(i==0)
		    			tmp.plaka = atoi(pt);
		    		else if(i==1)
		    			strcpy(tmp.name,pt);
		    		else if(i==2)
		    			strcpy(tmp.bolge,pt);
		    	}
		    	++i;
		        pt = strtok (NULL, ",");
		    }
		tmp.komsuSayisi = i-3;
    	addItem(&mainList,tmp);	
    }

    int tercih;
    do
	{
 		printf("___ MENU ___\n");
 		printf("[1] Bütün şehirleri yazdirmak için (1)\n");
 		printf("[2] Yeni bir komşuluk eklemek için (2) \n");
 		printf("[3] Şehir ismi ile aramak için (3)\n");
 		printf("[4] Plaka kodu ile aramak için (4)\n");
 		printf("[5] Listeden şehir silmek için (5)\n");
 		printf("[6] Herhangi bir komşuluk kaydı silmek için (6)\n");
 		printf("[7] Seçilen bölgede bulunan şehirler için (7)\n");
 		printf("[8] Komşu sayısı kriterine uyan şehirler için (8)\n");
 		printf("[9] Çıkış için (9)\n");
 		printf("Tercih Ettiginiz Islem Numarasi: ");


 		scanf("%d",&tercih);	
	 	
	 	switch (tercih){
				case 1:

				printList(mainList);
				break;
				 
				case 2:
				
				printf("Bu ister henüz yapilmadi\n");

				break;

				case 3: 
				printf("---------------------------------\n");
				printf("Lütfen aramak istediğiniz şehri baş harfi büyük şeklinde yazınız:");
				char sehir[54];
				scanf("%s",sehir);
				findAndPrintByName(mainList,sehir);				
				break;

				case 4:
				printf("---------------------------------\n");
				printf("Lütfen aramak istediğiniz şehrin plaka kodunu yazınız(1-81):");
				int kod;
				scanf("%d",&kod);
				findAndPrintByPlaka(mainList,kod);
				
				break;

				case 5:
				
				printf("Bu ister henüz yapilmadi\n");

				break;

				case 6:
				
				printf("Bu ister henüz yapilmadi\n");

				break;

				case 7:
				printf("---------------------------------\n");
				printf("Lütfen aramak istediğiniz bölgeyi yazınız(IA,EG...):");
				char bolge[2];
				scanf("%s",bolge);
				printByBolge(mainList,bolge);
				break;

				case 8:
				printf("Girdiğiniz komşu sayısından büyük,küçük,eşit olan şehirler\n");
				int bul;
				scanf("%d",&bul);
				printf("-----------------------\n");
				printBiggerKomsu(mainList,bul);
				printf("-----------------------\n");
				printSmallerKomsu(mainList,bul);
				printf("-----------------------\n");
				printEqualKomsu(mainList,bul);
				break;
				
				default:
				   	printf("Programdan çıkılıyor!!");
	 	}

	}while(tercih != 9);

	fclose(fp);

	return 0;
}